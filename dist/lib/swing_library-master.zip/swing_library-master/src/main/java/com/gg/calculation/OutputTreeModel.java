/*
 * Created on 22/06/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.gg.calculation;

import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

public class OutputTreeModel extends DefaultTreeModel {

	public OutputTreeModel(TreeNode root) {
		super(root);
	}
}
