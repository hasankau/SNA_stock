package com.gg.calculation.model;

import java.io.Serializable;

public abstract class Output implements Serializable
{
	public abstract String getType();
	
	public abstract String getName();
	
//	public abstract int getPosition();
	
}