package com.gg.calculation.model.operators;



public class PowerOperator extends Operator {

	public String getSymbol() {
		return "^";
	}

	public String getName() {
		return "power";
	}

	public Long getIdentifier() {

		return null;
	}
}
